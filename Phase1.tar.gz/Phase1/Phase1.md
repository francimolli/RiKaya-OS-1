Il livello 2 di RiKaya (Livello delle Code) 
fornisce l’implementazione delle strutture dati 
utilizzate dal livello sovrastante (kernel). 
