# RiKaya-OS
2018 - 2019 

O.S. for the "Sistemi Operativi" course. 

-Francesco Mollica
-Giosuè Cotugno
-Michele Gaspari
-Stefano Faieta
